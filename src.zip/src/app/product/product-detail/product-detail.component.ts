import { Component, OnInit } from "@angular/core";
import { Iproduct, Ireview } from "../product";
import { NgbRatingConfig } from "@ng-bootstrap/ng-bootstrap";
import { ProductserviceService } from "../../services/product.services";
import { Category } from "../../navigation/category";
import { CategoriesService } from "../../navigation/categories.service";
import { Slider } from "../../home/slider";
import { ActivatedRoute } from "@angular/router";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import {
  NgxGalleryOptions,
  NgxGalleryImage,
  NgxGalleryAnimation
} from "ngx-gallery";
import { ToastrService } from '../../../../node_modules/ngx-toastr';

@Component({
  selector: "app-product-detail",
  templateUrl: "./product-detail.component.html",
  styleUrls: ["./product-detail.component.css"]
})
export class ProductDetailComponent implements OnInit {
  galleryOptions: NgxGalleryOptions[];
  galleryImages: NgxGalleryImage[];
  addCart: FormGroup;
  submitted = false;
  qty = 1;

  model: any = {};
  products: Iproduct[];
  categories: Category[];
  categorycurrentProduct={};
  stars: Ireview[];
  mainImage: string;
  prdName: any;
  prdSku: any;
  prdPrice: any;
  baseImages: any;
  arrayImages = [];
  currentProduct = {};
  pId;
  cId;
  categoryName: any;
  recentPrd: any = [];

  firstNameToUpperCase(value: string) {
    if (value.length > 0)
      this.model.Name = value.charAt(0).toUpperCase() + value.slice(1);
    else this.model.Name = value;
  }
  constructor(
    private Productservice: ProductserviceService,
    private Ratingconfig: NgbRatingConfig,
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private router: Router,
    private CategoryService: CategoriesService,
    public toastr: ToastrService
  ) {
    Ratingconfig.max = 5;
    Ratingconfig.readonly = true;
  }

  ngOnInit(): void {
    //get Product Id
    this.pId = this.route.snapshot.paramMap.get("id");    
    this.addCart = this.formBuilder.group({
      qty: [1, Validators.required]
    });

    this.Productservice.getProducts().subscribe(data => {
      this.products = data as Iproduct[];
      this.products.forEach(product => {
        if (product["productId"] == this.pId) {
          //console.log(product);
          this.currentProduct = product;
          this.stars = product["reviews"];
          this.mainImage = product["baseImages"][0];
          this.baseImages = product["baseImages"];
          this.prdName = product["name"];
          this.prdSku = product["sku"];
          this.prdPrice = product["price"];
          //get Category Id
          this.cId = product["category_id"];
          this.CategoryService.getCategories().subscribe(data => {
            this.categoryName=data.filter(category=>category.categoryId==this.cId);
            this.categoryName =this.categoryName[0].name;
          });     
          //for image slider generate array
          this.baseImages.forEach(image => {
            var sliderArray = {
              small: "../../assets/images/product/" + image,
              medium: "../../assets/images/product/" + image,
              big: "../../assets/images/product/" + image
            };
            this.arrayImages.push(sliderArray);
          });
          this.galleryImages = this.arrayImages;

          if(localStorage.getItem("logedUser")) {
            var itemData = [];
            var count = 1;
            var isPush = true;
            var currentUser = localStorage.getItem("logedUserEmail");
            var userData = JSON.parse(localStorage.getItem(currentUser));
            if (userData[0]["recentPrd"]) {
              itemData = userData[0]["recentPrd"];
              itemData.forEach(product => {
                if(product.productId == this.pId) {
                  product.count += 1;
                  isPush = false;
                }
              });
            }
            if(isPush) {
              itemData.push({
                productId: this.pId,
                name: this.prdName,
                sku: this.prdSku,
                price:this.prdPrice,
                image: this.mainImage,
                count: count
              });
            }
            
            userData[0]["recentPrd"] = itemData;
            localStorage.setItem(currentUser, JSON.stringify(userData));
          }
        }
      });
    });
    //for image slider configuration
    this.galleryOptions = [
      {
        width: "80%",
        height: "700px",
        thumbnailsColumns: 4,
        imageDescription: true,
        imageAnimation: NgxGalleryAnimation.Slide
      },
      // max-width 800
      {
        breakpoint: 800,
        width: "90%",
        height: "800px",
        imagePercent: 80,
        thumbnailsPercent: 20,
        thumbnailsMargin: 20,
        thumbnailMargin: 20
      },
      // max-width 400
      {
        breakpoint: 400,
        width: "100%",
        height: "600px",
        imagePercent: 80,
        thumbnailsPercent: 20,
        thumbnailsMargin: 20,
        thumbnailMargin: 20
      },
      { "breakpoint": 300, "width": "100%", "height": "400px", "thumbnailsColumns": 2 }
    ];
  }

  get f() {
    return this.addCart.controls;
  }

  buyNow() {
    this.submitted = true;

    //stop here if form is invalid
    if (this.addCart.invalid) {
      return;
    }

    if (localStorage.getItem("logedUser")) {
      var qty = parseInt(this.addCart.value.qty);
      var cartData = [];
      
      var subTotal;
      var grandTotal;
      var totalQuantity;
      var shippingCharge;
      var shippingMethod;
      var currentUser = localStorage.getItem("logedUserEmail");
      var UserData = JSON.parse(localStorage.getItem(currentUser));
      localStorage.removeItem(currentUser);

      if (UserData[0]["cartData"]) {
        cartData = UserData[0]["cartData"]["productData"];
        var oldCart = UserData[0]["cartData"];
        subTotal = oldCart["subTotal"] + this.prdPrice * qty;
        grandTotal = oldCart["grandTotal"] + this.prdPrice * qty;
        totalQuantity = parseInt(oldCart["totalQuantity"]) + qty;
        shippingCharge = oldCart["shippingCharge"];
        shippingMethod = oldCart["shippingMethod"];
      } else {
        subTotal = this.prdPrice * qty;
        grandTotal = this.prdPrice * qty + 0;
        totalQuantity = qty;
        shippingCharge = 0;
        shippingMethod = "free";
      }
      cartData.push({
        productId: this.pId,
        name: this.prdName,
        sku: this.prdSku,
        quantity: qty,
        price: this.prdPrice * qty,
        productPrice: this.prdPrice,
        image: this.mainImage
      });

      var cart = {
        productData: cartData,
        subTotal: subTotal,
        grandTotal: grandTotal,
        totalQuantity: totalQuantity,
        shippingCharge: shippingCharge,
        shippingMethod: shippingMethod
      };

      document.getElementById("miniCart").innerHTML= '<img src="assets/icons/cart_normal.svg" alt="cart" class="pl-4 pr-2" aria-hidden="true"><sup>'+totalQuantity+'</sup>';
      UserData[0]["cartData"] = cart;
      localStorage.setItem(currentUser, JSON.stringify(UserData));
      this.router.navigate(["/cart"]);
    }
    else {
      let element = document.getElementById('signIn');
      element.click();
    }
  }
  addToCart() {
    this.submitted = true;

    //stop here if form is invalid
    if (this.addCart.invalid) {
      return;
    }

    if (localStorage.getItem("logedUser")) {
      var qty = parseInt(this.addCart.value.qty);
      var cartData = [];
      var subTotal;
      var grandTotal;
      var totalQuantity;
      var shippingCharge;
      var shippingMethod;
      var currentUser = localStorage.getItem("logedUserEmail");
      var UserData = JSON.parse(localStorage.getItem(currentUser));
      localStorage.removeItem(currentUser);

      if (UserData[0]["cartData"]) {
        cartData = UserData[0]["cartData"]["productData"];
        var oldCart = UserData[0]["cartData"];
        subTotal = oldCart["subTotal"] + this.prdPrice * qty;
        grandTotal = oldCart["grandTotal"] + this.prdPrice * qty;
        totalQuantity = parseInt(oldCart["totalQuantity"]) + qty;
        shippingCharge = oldCart["shippingCharge"];
        shippingMethod = oldCart["shippingMethod"];
      } else {
        subTotal = this.prdPrice * qty;
        grandTotal = this.prdPrice * qty + 0;
        totalQuantity = qty;
        shippingCharge = 0;
        shippingMethod = "free";
      }
      cartData.push({
        productId: this.pId,
        name: this.prdName,
        sku: this.prdSku,
        quantity: qty,
        price: this.prdPrice,
        productPrice: this.prdPrice,
        image: this.mainImage
      });

      var cart = {
        productData: cartData,
        subTotal: subTotal,
        grandTotal: grandTotal,
        totalQuantity: totalQuantity,
        shippingCharge: shippingCharge,
        shippingMethod: shippingMethod
      };
      //console.log(cart);
      UserData[0]["cartData"] = cart;
      localStorage.setItem(currentUser, JSON.stringify(UserData));
      document.getElementById("miniCart").innerHTML= '<img src="assets/icons/cart_normal.svg" alt="cart" class="pl-4 pr-2" aria-hidden="true"><sup>'+totalQuantity+'</sup>';
      this.toastr.success('You have successfully added the item to cart.');
    }
    else {
      let element = document.getElementById('signIn');
      element.click();
    }
  }

  triggerClick() {
    let element = document.getElementById('signIn');
    element.click();
  }
  toggleSign(arg): void {
      let id=document.getElementById(arg);
       var src = id.getAttribute("src");
      if(src=="assets/icons/heart_normal.svg"){
       src="assets/icons/heart_selected.svg";
      }
      else{
        src="assets/icons/heart_normal.svg";
      }
      id.setAttribute("src", src);
    }
    readMorebtn(){
    var text=document.getElementById("more");
    var text1=document.getElementById("read");
    if(text.style.display=="none")
    {
      text1.innerHTML="Read less";
      text.style.display="block";
    }
    else{
      text1.innerHTML="Read more";
      text.style.display="none";
    }
  }
}
