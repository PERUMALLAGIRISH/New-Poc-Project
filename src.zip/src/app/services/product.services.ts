import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Iproduct } from "../product/product";
// import * as firebase from "firebase";
// import firestore from "firebase/firestore";
import { Observable } from "rxjs";
import { map } from "rxjs/operators";

@Injectable({
  providedIn: "root"
})
export class ProductserviceService {
  alldata: object;
  categoryFilter: Iproduct[];
  contentArray: Iproduct[];
  returnedArray: Iproduct[];
  //users = firebase.firestore().collection("userDatas");

  constructor(private http: HttpClient) {}

  getProducts() {
    return this.http.get<Iproduct[]>("../assets/json/products.json");
  }

  // getData(id) {
  //   this.getProducts().subscribe(data => { 
  //     //this.products = data;
  //     this.categoryFilter=data.filter(
  //       product=>product.category_id==id);
  //     console.log(this.categoryFilter);
      
  //     this.contentArray=this.categoryFilter;
        
  //     this.returnedArray = this.contentArray.slice(0, 6);
  //   });
  //   return this.returnedArray;
  // }

 /* getUsers(): Observable<any> {
    return new Observable(observer => {
      this.users.onSnapshot(querySnapshot => {
        querySnapshot.forEach(doc => {
          var data = doc.data();

          observer.next(data);
        });
      });
    });
  }
  postBoards(data): Observable<any> {
    return new Observable(observer => {
      this.users.add(data).then(doc => {
        observer.next({
          key: doc.id
        });
      });
    });
  }
  deleteBoards(id: string): Observable<{}> {
    return new Observable(observer => {
      this.users
        .doc(id)
        .delete()
        .then(() => {
          observer.next();
        });
    });
  } */
}
