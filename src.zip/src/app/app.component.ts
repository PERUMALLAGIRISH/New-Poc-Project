import { Component, OnInit } from "@angular/core";
import { Router, NavigationEnd } from '@angular/router';
// import * as firebase from "firebase";
// import firestore from "firebase/firestore";

// const settings = { timestampsInSnapshots: true };
// const config = {
//   apiKey: "AIzaSyAA9vXDuPLTRu7aOJHXK0JkKuB2Z6s1CRk",
//   authDomain: "pocdemo-4acc2.firebaseapp.com",
//   databaseURL: "https://pocdemo-4acc2.firebaseio.com",
//   projectId: "pocdemo-4acc2",
//   storageBucket: "pocdemo-4acc2.appspot.com"
// };

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"]
})
export class AppComponent implements OnInit {
  constructor(private router: Router) { }
  title = "poc";

  ngOnInit() {
    this.router.events.subscribe((evt) => {
      if (!(evt instanceof NavigationEnd)) {
          return;
      }
      window.scrollTo(0, 0)
  });
    // firebase.initializeApp(config);
    // firebase.firestore().settings(settings);
  }
}
