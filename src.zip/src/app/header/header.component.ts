import { Component, OnInit, ElementRef } from "@angular/core";
import {
  trigger,
  state,
  style,
  animate,
  transition
} from "@angular/animations";
import { Router } from "../../../node_modules/@angular/router";
import { DeviceDetectorService } from "ngx-device-detector";
import { CategoriesService } from "../navigation/categories.service";
import { Category } from "../navigation/category";
import {
  FormGroup,
  FormBuilder,
  Validators
} from "../../../node_modules/@angular/forms";

@Component({
  selector: "app-header",
  templateUrl: "./header.component.html",
  styleUrls: ["./header.component.css"],
  animations: [
    trigger("slideMenu", [
      state(
        "open",
        style({
          transform: "translateX(0%)"
        })
      ),
      state(
        "close",
        style({
          transform: "translateX(-105%)"
        })
      ),
      transition("open=>close", animate("300ms")),
      transition("close=>open", animate("200ms"))
    ]),
    trigger("FadeAnimation", [
      state(
        "in",
        style({
          opacity: "1",
          display: "block"
        })
      ),
      state(
        "out",
        style({
          opacity: "0",
          display: "none"
        })
      ),
      transition("in=>out", animate("500ms")),
      transition("out=>in", animate("500ms"))
    ]),
    trigger("changeDivSize", [
      state(
        "initial",
        style({
          width: "100px",
          height: "30px",
          display: "none"
        })
      ),
      state("final", style({
        
      })),
      transition("initial=>final", animate("500ms")),
      transition("final=>initial", animate("200ms"))
    ])
  ],
  host: {
    "(document:click)": "onClick($event)"
  }
})
export class HeaderComponent implements OnInit {
  searchForm: FormGroup;
  submitted = false;
  public show: boolean = false;
  logedUser: boolean = false;
  currentUser: string;
  userDetails: any;
  cartAll: any;
  totalQty: number;
  isCartQty: boolean = false;
  currentState = "initial";
  menuState = "close";
  fadeState = "out";
  icon: string;
  categoriesList: Category[];
  errorMessage: any;
  isMobile: boolean = false;
  menuClicked: boolean = true;
  showCartImage: boolean = false;
  showUserImage: boolean = false;
  showSearchImage: boolean = false;
  clickUserImage: boolean = false;
  searchIcon:string = 'assets/icons/Search_Icon_Normal.svg';
  cartIcon:string = 'assets/icons/CartIconNormal.svg';
  profiletIcon:string = 'assets/icons/ProfileIconNormal.svg';
  constructor(
    private _eref: ElementRef,
    private router: Router,
    private formBuilder: FormBuilder,
    private deviceService: DeviceDetectorService,
    private categoriesService: CategoriesService
  ) {}

  ngOnInit() {
    this.isMobile = this.deviceService.isMobile();
    this.categoriesService.getCategories().subscribe(
      data => {
        this.categoriesList = data;
        console.log(this.categoriesList);
      },
      error => (this.errorMessage = <any>error)
    );
    if (localStorage["logedUser"] == "true") {
      this.showUserImage = true;
    }
    if (localStorage["logedUser"] == "true") {
      this.logedUser = !this.logedUser;
      this.currentUser = localStorage.getItem("logedUserEmail");
      this.userDetails = JSON.parse(localStorage.getItem(this.currentUser));
      this.cartAll = this.userDetails[0].cartData;
      if (this.cartAll) {
        this.totalQty = this.cartAll.totalQuantity;
      } else {
        this.totalQty = 0;
      }

      if (this.totalQty > 0) {
        this.isCartQty = true;
      } else {
        this.isCartQty = false;
      }
    }

    this.searchForm = this.formBuilder.group({
      search: ["", Validators.required]
    });
    this.icon = "fa-chevron-down";
    document.getElementById('searchClose').style.display="none";
  }

  showMewnu() {
    this.menuState = "open";
    this.fadeState = "in";
  }
  closeMenu() {
    this.menuState = "close";
    this.fadeState = "out";
  }
  cnangeIcon(event, i) {
    console.log(this.menuClicked);
    if (this.menuClicked == true) {
      event.target.classList.remove("fa-chevron-down");
      event.target.classList.add("fa-chevron-up");
      document.getElementById("mbl-h" + i).style.color = "#0088FF";
      event.target.style.color = "#0088FF";
      this.menuClicked = false;
    } else {
      event.target.classList.remove("fa-chevron-up");
      event.target.classList.add("fa-chevron-down");
      document.getElementById("mbl-h" + i).style.color = "gray";
      event.target.style.color = "gray";
      this.menuClicked = true;
    }
  }
changeSearchicon(state){
  if(state == 1){
    this.searchIcon = "assets/icons/SearchIconSelected.svg";
  }else{
    this.searchIcon = "assets/icons/Search_Icon_Normal.svg"; 
  }  
}
changeCarticon(state){
  if(state == 1){
    this.cartIcon = "assets/icons/CartIconSelected.svg";
  }else{
    this.cartIcon = "assets/icons/CartIconNormal.svg"; 
  }  
}
changeUsericon(state){
  if(state == 1){
    this.profiletIcon = "assets/icons/ProfileIconSelected.svg";
  }else{
    this.profiletIcon = "assets/icons/ProfileIconNormal.svg"; 
  }  
}
  // convenience getter for easy access to form fields
  get f() {
    return this.searchForm.controls;
  }
  toggle() {
    this.profiletIcon = "assets/icons/ProfileIconSelected.svg";
    if (!localStorage["logedUser"]) {
      this.showUserImage = !this.showUserImage;
    }
    this.show = !this.show;
  }
  changeState(event) {
    if(this.currentState == 'initial'){
      document.getElementById('searchOpen').style.display="none";
      document.getElementById('searchClose').style.display="inline";
      this.currentState = 'final';
    }else{
      document.getElementById('searchOpen').style.display="inline";
      document.getElementById('searchClose').style.display="none";
      this.currentState = 'initial';
    }
     
   

  }
  onClick(event) {
    if (event.target.id != "dropdownMenuLink" && this.show) {
      this.show = !this.show;
      if (!localStorage["logedUser"]) {
        this.showUserImage = !this.showUserImage;
      }
    }
  }
  signOut() {
    localStorage.removeItem("logedUser");
    localStorage.removeItem("logedUserEmail");
    this.router.navigate(["/"]);
    location.reload();
  }
  onSearch() {
    this.submitted = true;
    if (this.searchForm.invalid) {
      return;
    }
    let value = this.searchForm.value.search;
    this.router.navigate(["/search/" + value]);
  }
  toggleSearchImage() {
    this.showSearchImage = !this.showSearchImage;
  }
}
