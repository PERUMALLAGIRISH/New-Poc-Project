import { Component, OnInit } from '@angular/core';
import { OrderService } from './order.service';
import { IProduct } from './orderdetails';
import {PageChangedEvent}from 'ngx-bootstrap/pagination';


@Component({
  selector: 'app-order-list',
  templateUrl: './order-list.component.html',
  styleUrls: ['./order-list.component.css'],
  providers: [OrderService]
})
export class OrderListComponent implements OnInit {

  orderdetails:IProduct[];
  detailsservice: any;
  data: IProduct[]=[];
  currentUser = localStorage.getItem("logedUserEmail");

  contentArray = new Array().fill('');
  

  items:IProduct[];
  totalItems:number;  
//
  _listFilter: string;
get listFilter(): string{
  return this._listFilter;
}
set listFilter(value:string) {
  this._listFilter = value;
  this.data= this.listFilter ? this.performFilter(this.listFilter) : this.orderdetails;
}
filteredProducts: IProduct[];
  products:IProduct[]=[];
//
  constructor(private orderService:OrderService) {
    //
    this.filteredProducts = this.orderdetails;
    this.listFilter ='';
    //
}
//
// onRatingClicked(message:string): void{
//   this.pageTitle=''+message;
// }
performFilter(filterBy: string) : IProduct[] {
 // console.log(filterBy);
  
  filterBy = filterBy.toLocaleLowerCase();
  //console.log(filterBy);
  //console.log(this.products[0].DatePlaced);
  
  return this.orderdetails.filter((product: IProduct) =>
  product.DatePlaced.toLocaleLowerCase().indexOf(filterBy) !== -1);
}
//

  //  onNotify(message:string):void{

  //  }
  // //  products: IProduct[];

  ngOnInit():void 
  {
    // this.orderService.getData().subscribe(
    //   data => {
    //     this.contentArray = data;
    //     // this.contentArray = products;
    //     this.data=this.contentArray.slice(0,10); 
    //     console.log(this.contentArray);
    //   }
    // );
    this.orderdetails =JSON.parse(localStorage.getItem(this.currentUser))[0]["orderData"]['orders'];
    this.contentArray = this.orderdetails;
    // console.log(JSON.parse(localStorage.getItem(this.currentUser))[0]["orderData"]['orders']);
    
    // this.orderService.getData().subscribe(
    //   products => {         
    //     // this.products = products;
    //     // this.filteredProducts = this.products;
    //     this.contentArray = products;
    //     this.data=this.contentArray.slice(0,10);   
    //   });
      // this.data.forEach(function(element) {
      //   console.log(element);
      // })
    // this.products =JSON.parse(localStorage.getItem(this.currentUser))[0]["orderData"]['orders'];
    // this.contentArray = this.products;
    this.orderdetails=this.contentArray.slice(0,4);   
 
  }
  pageChanged(event:PageChangedEvent):void{
    const startItem = (event.page -1) * event.itemsPerPage;
    const endItem = event.page * (event.itemsPerPage);
    this.orderdetails = this.contentArray.slice(startItem, endItem);
  }

}
