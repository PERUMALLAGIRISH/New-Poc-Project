import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";

@Component({
  selector: 'app-success',
  templateUrl: './success.component.html',
  styleUrls: ['./success.component.css']
})
export class SuccessComponent implements OnInit {
  [x: string]: any;
  orderId: any;
  status: string;
  date: any;
  total: any;
  currentUser = localStorage.getItem("logedUserEmail");

  constructor(private router: Router) { }

  ngOnInit() {
    document.getElementById("navbar").style.display = "none";
    var orderDetails = JSON.parse(localStorage.getItem("lastOrder"));
    if (orderDetails) {
      this.orderId = orderDetails.orderInfo['orderId'];
      this.status = "Ready";
      this.date = orderDetails.orderInfo['datePlace'];
      this.total = orderDetails.orderInfo['grantTotal'];
      this.subTotal = orderDetails.orderInfo['subTotal'];
      this.shipAmount = orderDetails.orderInfo['shipAmount'];
      this.paymentNo = orderDetails.orderInfo['payment'];
      this.shipMethodname = orderDetails.orderInfo['shipMethodname'];
      this.productData = orderDetails.productData;
      this.addr = orderDetails.addr;
    }else{
      this.router.navigate(['/']);
    }
    localStorage.removeItem("lastOrder");
    let updatedCartall = JSON.parse(localStorage.getItem(this.currentUser));
    updatedCartall[0].cartData = '';
    document.getElementById("miniCart").innerHTML= '<img src="assets/icons/cart_normal.svg" alt="cart" class="pl-4 pr-2" aria-hidden="true"><sup>0</sup>';
    localStorage.setItem(
      this.currentUser,
      JSON.stringify(updatedCartall)
    );

  }
}
