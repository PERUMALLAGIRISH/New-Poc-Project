import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-success',
  templateUrl: './success.component.html',
  styleUrls: ['./success.component.css']
})
export class SuccessComponent implements OnInit {
  [x: string]: any;
  orderId: any;
  status: string;
  date: any;
  total: any;

  constructor() { }

  ngOnInit() {
    var orderDetails = JSON.parse(localStorage.getItem("lastOrder"));
    if (orderDetails) {
      this.orderId = orderDetails.orderInfo['orderId'];
      this.status = "Ready";
      this.date = orderDetails.orderInfo['datePlace'];
      this.total = orderDetails.orderInfo['grantTotal'];
      this.subTotal = orderDetails.orderInfo['subTotal'];
      this.shipAmount = orderDetails.orderInfo['shipAmount'];
      this.paymentNo = orderDetails.orderInfo['payment'];
      this.shipMethodname = orderDetails.orderInfo['shipMethodname'];
      this.productData = orderDetails.productData;
      this.addr = orderDetails.addr;
    }
  }
}
