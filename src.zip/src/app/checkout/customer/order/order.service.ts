import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';

import {Observable} from 'rxjs';
import {IProduct} from './orderdetails';

@Injectable({
    providedIn: 'root'
})
export class OrderService {
    alldata:object;
    constructor(private http:HttpClient) {}
    getData(): Observable<IProduct[]> {
        return this.http.get<IProduct[]>('./assets/order.json');
    }
}

