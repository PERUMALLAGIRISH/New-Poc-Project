import { Component, OnInit } from '@angular/core';
import { OrderService } from './order.service';
import { IProduct } from './orderdetails';
import {PageChangedEvent}from 'ngx-bootstrap/pagination';
import { DatePipe } from '@angular/common'


@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css'],
  providers: [OrderService]
})
export class OrderComponent implements OnInit {

  orderdetails:IProduct[];
  detailsservice: any;
  data: IProduct[]=[];

  contentArray = new Array().fill('');
  

  items:IProduct[];
  totalItems:number;  
//
  _listFilter: string;
get listFilter(): string{
  return this._listFilter;
}
set listFilter(value:string) {
  this._listFilter = value;
  this.data= this.listFilter ? this.performFilter(this.listFilter) : this.products;
}
filteredProducts: IProduct[];
  products:IProduct[]=[];
//
  constructor(private orderService:OrderService, public datepipe: DatePipe) {
    //
    this.filteredProducts = this.products;
    this.listFilter ='';
    //
}
//
// onRatingClicked(message:string): void{
//   this.pageTitle=''+message;
// }
performFilter(filterBy: string) : IProduct[] {
 // console.log(filterBy);
  
  filterBy = filterBy.toLocaleLowerCase();
  //console.log(filterBy);
  //console.log(this.products[0].DatePlaced);
  
  return this.products.filter((product: IProduct) =>
  product.DatePlaced.toLocaleLowerCase().indexOf(filterBy) !== -1);
}
//

  //  onNotify(message:string):void{

  //  }
  // //  products: IProduct[];

  ngOnInit():void 
  {
    this.orderService.getData().subscribe(
      products =>{
        
        this.products = products;
        this.filteredProducts = this.products;

        this.contentArray = products;
        this.data=this.contentArray.slice(0,10);    
      });
 
  }
  pageChanged(event:PageChangedEvent):void{
    const startItem = (event.page -1) * event.itemsPerPage;
    const endItem = event.page * (event.itemsPerPage);
    this.data = this.contentArray.slice(startItem, endItem);
  }
  
  
    
}

