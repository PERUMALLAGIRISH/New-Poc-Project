import { Component, OnInit } from "@angular/core";
import { OtherserviceService } from "../../services/other.services";
import { Slider } from "./slider";
import { CategoriesService } from '../../navigation/categories.service';
import { Category } from "../../navigation/category";
import { Iproduct } from "../../product/product";
import { ProductserviceService } from '../../services/product.services';
import { ToppicksService } from "./toppicks.service";

@Component({
    selector: 'app-toppicks',
    templateUrl: './toppicks.component.html',
    styleUrls: ['./toppicks.component.css']
  })

export class ToppicksComponent implements OnInit {
  sliderArray: Slider[];
  categoriesList: Category[];
  myInterval: number = 2500;
  activeSlideIndex = 0;
  errorMessage: any;
  featureProduct: Iproduct[];
  filteredItems:any;
  currentUser: string;
  updatedCartList: any;
  updatedCartall: any;
  recentProduct: any;
  pdData: any = [];  
  pID:any;
  
  constructor(public slider: OtherserviceService,private categoriesService: CategoriesService,
    private productService: ProductserviceService,private relatedProductsService: ToppicksService) {
    this.sliderArray = [];
  }

  ngOnInit() {
    this.slider.getSlider().subscribe((result: Slider[] = []) => {
      this.sliderArray = result;
      this.sliderArray = this.sliderArray;
    });
    this.categoriesService.getCategories().subscribe(
      data => {
        this.categoriesList = data;
      },
      error => (this.errorMessage = <any>error)
    );
    this.productService.getProducts().subscribe(data => { 
      this.pdData=data;     
      this.currentUser = localStorage.getItem("logedUserEmail");
      this.updatedCartall = JSON.parse(localStorage.getItem(this.currentUser));
      this.updatedCartList = this.updatedCartall[0].cartData;
      let prdArray=[];
      for(let i=0;i<this.updatedCartList.productData.length;i++){
        this.pID=this.updatedCartList.productData[i].productId;
        prdArray.push(this.pID) 
      }
      let matchprd:any;
      let productsData:any=[];
      for(let i=0;i<prdArray.length;i++){
        matchprd=this.pdData.filter(
        product=>product.productId==prdArray[i]);
        //console.log(matchprd[0]);
        let value=matchprd[0].relatedProducts.replace('"','')+","
        productsData=productsData+value
      }
      productsData=productsData.split(",");
      this.pID=removeDuplicates(productsData);
      function removeDuplicates(arr){
        let unique_array = []
        for(let i = 0;i < arr.length; i++){
            if(unique_array.indexOf(arr[i]) == -1){
                unique_array.push(arr[i])
            }
        }
        return unique_array
      }
      let finaldat=[];
      let finaldat1=[];
      for(let i=0;i<this.pID.length-1;i++){
        finaldat=this.pdData.filter(
          product=>product.productId==this.pID[i]);
          finaldat1.push(finaldat[0]);
      }
      this.featureProduct = this.chunks(finaldat1,3);
    });
    this.currentUser = localStorage.getItem("logedUserEmail");
    this.updatedCartall = JSON.parse(localStorage.getItem(this.currentUser));
    this.updatedCartList = this.updatedCartall[0].recentPrd;
    this.updatedCartList.sort(this.sortByCount).reverse();
    this.recentProduct =this.chunks(this.updatedCartList,3);
  }

  chunks(array, size) {
    let results = [];
    results = [];
    while (array.length) {
      results.push(array.splice(0, size));
    }
    return results;
  }
  sortByCount(a: any, b: any) {
    if (a.count > b.count) return 1;
    else if (a.count === b.count) return 0;
    else return -1;
  }

  toggleSign(arg): void {
      let id=document.getElementById(arg);
       var src = id.getAttribute("src");
      if(src=="assets/icons/heart_normal.svg"){
       src="assets/icons/heart_selected.svg";
      }
      else{
        src="assets/icons/heart_normal.svg";
      }
      id.setAttribute("src", src);
    }
}


