import { Component, OnInit } from "@angular/core";
import { OtherserviceService } from "../services/other.services";
import { Slider } from "./slider";
import { CategoriesService } from '../navigation/categories.service';
import { Category } from '../navigation/category';
import { Iproduct } from '../product/product';
import { ProductserviceService } from '../services/product.services';

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.css"]
})
export class HomeComponent implements OnInit {
  sliderArray: Slider[];
  categoriesList: Category[];
  myInterval: number = 2500;
  activeSlideIndex = 0;
  errorMessage: any;
  featureProduct: Iproduct[];
  filteredItems:any;
showIcon:boolean=false;
// isActive:boolean=false;
// imgSrc:any;
  constructor(public slider: OtherserviceService,private categoriesService: CategoriesService,
    private Productservice: ProductserviceService,) {
    this.sliderArray = [];    
  }

  ngOnInit() {
    // document.getElementById("navbar").style.display = "block";
    this.slider.getSlider().subscribe((result: Slider[] = []) => {
      this.sliderArray = result;
      console.log(this.sliderArray);
      this.sliderArray = this.sliderArray;
    });
    this.categoriesService.getCategories().subscribe(
      data => {
        this.categoriesList = data;
      },
      error => (this.errorMessage = <any>error)
    );
    this.Productservice.getProducts().subscribe(data => {
      this.featureProduct = this.chunks(data,3);  
    });
    var dots = document.getElementById("more");
    dots.style.display = "none";
  }

  chunks(array, size) {
    let results = [];
    results = [];
    while (array.length) {
      results.push(array.splice(0, size));
    }
    return results;
  }

  toggleSign(product): void {
    let idval;
    idval = document.getElementById(product);
    console.log(idval);
    if (idval.className == "heart fa fa-heart")
      idval.className = idval.className.replace(
        /\bheart fa fa-heart\b/g,
        "heart fa fa-heart active"
      );
    else
      idval.className = idval.className.replace(
        /\bheart fa fa-heart active\b/g,
        "heart fa fa-heart"
      );
  }
  ReadMoreBtn(){
   
  var moreText = document.getElementById("more");
  var btnText = document.getElementById("readMoreTextBtn");
  if (moreText.style.display == "none") {
   // dots.style.display = "inline";
    btnText.innerHTML = "Read less"; 
    moreText.style.display = "block";
  } 
  else {
    btnText.innerHTML = "Read more"; 
    //moreText.style.display = "inline";
     moreText.style.display = "none";
  }
}
toggleImage(){
  this.showIcon=!this.showIcon;
}

}
