import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { DeviceDetectorModule } from "ngx-device-detector";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { AppRoutingModule } from "./app-routing.module";
import { ReactiveFormsModule } from "@angular/forms";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { HttpClientModule } from "@angular/common/http";
import { ToastrModule } from "ngx-toastr";
import { NgxGalleryModule } from "ngx-gallery";
import { PaginationModule } from "ngx-bootstrap/pagination";
import { BsDropdownModule } from "ngx-bootstrap/dropdown";

import { AppComponent } from "./app.component";
import { CheckoutModule } from "./checkout/checkout.module";
import { NavigationComponent } from "./navigation/navigation.component";
import { HeaderComponent } from "./header/header.component";
import { UserComponent } from "./user/user.component";
import { RegisterComponent } from "./user/register/register.component";
import { LoginComponent } from "./user/login/login.component";
import { HomeComponent } from "./home/home.component";
import { ProductComponent } from "./product/product.component";
import { ProductDetailComponent } from "./product/product-detail/product-detail.component";
import { CarouselModule } from "ngx-bootstrap/carousel";
import { FooterComponent} from "./footer/footer.component"
import { AddressBookComponent} from "./user/address-book/address-book.component";
import { SearchComponent } from './product/search/search.component';
import { ManageaccountComponent } from './user/manageaccount/manageaccount.component';
import { ChangePasswordComponent } from './user/change-password/change-password.component';
import { AccountinformationComponent } from './user/accountinformation/accountinformation.component';
import { UserinformationComponent } from './user/userinformation/userinformation.component';

@NgModule({
  declarations: [
    AppComponent,
    UserComponent,
    RegisterComponent,
    LoginComponent,
    HeaderComponent,
    NavigationComponent,
    ProductComponent,
    ProductDetailComponent,
    HomeComponent,
    FooterComponent,
    AddressBookComponent,
    SearchComponent,
    ManageaccountComponent,
    ChangePasswordComponent,
    AccountinformationComponent,
    UserinformationComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    NgbModule,
    HttpClientModule,
    ToastrModule.forRoot(),
    DeviceDetectorModule.forRoot(),
    CheckoutModule,
    NgxGalleryModule,
    PaginationModule.forRoot(),
    BsDropdownModule.forRoot(),
    CarouselModule.forRoot()
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}
