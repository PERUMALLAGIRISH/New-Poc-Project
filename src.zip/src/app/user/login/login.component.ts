import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { ToastrService } from 'ngx-toastr';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  closeResult: string;

  submitted = false;
  constructor(private formBuilder: FormBuilder,
    public toastr: ToastrService,
    private router: Router,
    private modalService: NgbModal
  ) { }

  ngOnInit() {
    if (localStorage.getItem("logedUser")) {
      this.router.navigate(['/']);
    }
    this.loginForm = this.formBuilder.group(
    {
      userName: ["",Validators.required],
      password: ["",Validators.required]
    }
  );
}


// convenience getter for easy access to form fields
get f() {
  return this.loginForm.controls;
}

onSubmit() {
  this.submitted = true;
  var available = false;
  
  //stop here if form is invalid
  if (this.loginForm.invalid) {
    return;
  }

  var currrent_name = this.loginForm.value.userName;
  var currrent_pass = this.loginForm.value.password;
  console.log(currrent_name);
  console.log(currrent_pass);
    var datas = JSON.parse(localStorage["userDatas"]);    
    if(Object.keys(datas).length != 0){

      datas.forEach(function(element) {        
        if (element.email == currrent_name && element.password == currrent_pass) {  
          console.log(element.email);
          console.log(element.password);       
          available=true;
          return false;
        }           
      });      
    }
    if(available){
      localStorage["logedUser"] = JSON.stringify(true);   
      localStorage["logedUserEmail"] = this.loginForm.value.userName;       
      this.router.navigate(['/home']);
      location.reload();
    }else{
      this.toastr.error('Please check', 'User name or password invalied');
    }    
  }
}
