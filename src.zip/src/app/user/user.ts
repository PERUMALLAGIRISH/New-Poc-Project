export interface Iuser {
  userId: string;
  fname: string;
  lname: string;
  email: string;
  phNumber: string;
  addressLineOne: string;
  addressLineTwo: string;
  city: string;
  state: string;
  zipCode: string;
  country: string;
  password: string;
  termsAndCondition: string;
}
