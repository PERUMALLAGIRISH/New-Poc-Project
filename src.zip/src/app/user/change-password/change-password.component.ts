import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '../../../../node_modules/@angular/forms';
import { Router } from '../../../../node_modules/@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {
  changePasswordForm: FormGroup;
  submitted = false;
  loggedIn = false;
  msg: string = null;
  userEmail = localStorage["logedUserEmail"];
  constructor(private formBuilder: FormBuilder,private router: Router,private toastr: ToastrService) { }

  ngOnInit() {
    this.changePasswordForm = this.formBuilder.group({
      oldPassword: ['', [Validators.required, Validators.minLength(6)]],
      newPassword: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', Validators.required]
    }, {
      validator:this.matchValidator('newPassword','confirmPassword')
    });
  }
  matchValidator(controlName: string, matchingControlName: string) {
    return (formGroup: FormGroup) => {
      const control = formGroup.controls[controlName];
      const matchingControl = formGroup.controls[matchingControlName];

      if (matchingControl.errors && !matchingControl.errors.mustMatch) {
          // return if another validator has already found an error on the matchingControl
          return;
      }

      // set error on matchingControl if validation fails
      if (control.value !== matchingControl.value) {
          matchingControl.setErrors({ match: true });
      } else {
          matchingControl.setErrors(null);
      }
    }
  }
  // closeSuccessAlert() {
  //   this.alert.nativeElement.classList.remove('show');
  // }

  // closeWarningAlert() {
  //   this.alert.nativeElement.classList.remove('show');
  // }

  // convenience getter for easy access to form fields
  get f() { return this.changePasswordForm.controls; }

  onSubmit() {
    // localStorage[this.userEmail][0].password = 123456;
    this.submitted = true;
    this.loggedIn = true;
    // stop here if form is invalid
    if (this.changePasswordForm.invalid) {
      return;
    }
    let oldPassword = JSON.parse(localStorage.getItem(this.userEmail))[0].password;
    
    // let oldPassword = localStorage[this.userEmail];    
    if(oldPassword != this.changePasswordForm.value.oldPassword) {
      this.toastr.error('Old password is not correct.');
    }
    else {
      //let customer = JSON.parse(localStorage.getItem(this.userEmail))[0];
      //customer.password = this.changePasswordForm.value.newPassword;
      let customerAll = JSON.parse(localStorage.getItem(this.userEmail));
      let usercustomerAll = JSON.parse(localStorage.getItem("userDatas"));
      customerAll[0].password = this.changePasswordForm.value.newPassword;
      customerAll[0].confirmPassword = this.changePasswordForm.value.newPassword;
      usercustomerAll[0].password = this.changePasswordForm.value.newPassword;
      usercustomerAll[0].confirmPassword = this.changePasswordForm.value.newPassword;
     // localStorage[this.userEmail][0].password = this.changePasswordForm.value.newPassword;
      
      localStorage.setItem(
        this.userEmail,
        JSON.stringify(customerAll)
      );
      localStorage.setItem(
        "userDatas",
        JSON.stringify(usercustomerAll)
      );
      this.toastr.success('Password changed successfully.');
    }            
  }
}
