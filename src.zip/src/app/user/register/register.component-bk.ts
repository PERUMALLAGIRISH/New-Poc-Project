import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { MustMatch } from "../../helpers/must-match.validator";
import { ToastrService } from "ngx-toastr";
import { UserserviceService } from "../../services/user.services.";

@Component({
  selector: "app-register",
  templateUrl: "./register.component.html",
  styleUrls: ["./register.component.css"]
})
export class RegisterComponent implements OnInit {
  registerForm: FormGroup;
  submitted = false;
  alphaNumaric = "^[A-Za-z0-9_]{3,50}$";
  email = "^[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,4}$";
  numberonlyPhone = "^[0-9]{10,10}$";
  numberonlyZipCode = "^[0-9]{6,6}$";
  formdata = [];

  constructor(
    private formBuilder: FormBuilder,
    public toastr: ToastrService,
    private router: Router,
    private userService: UserserviceService
  ) {}

  ngOnInit() {
    if (localStorage.getItem("logedUser")) {
      this.router.navigate(['/']);
    }
    this.registerForm = this.formBuilder.group(
      {
        firstName: [
          "",
          [Validators.required, Validators.pattern(this.alphaNumaric)]
        ],
        lastName: [
          "",
          [Validators.required, Validators.pattern(this.alphaNumaric)]
        ],
        email: ["", [Validators.required, Validators.pattern(this.email)]],
        PhoneNumber: [
          "",
          [Validators.required, Validators.pattern(this.numberonlyPhone)]
        ],
        line1: ["", Validators.required],
        line2: [""],
        city: ["", Validators.required],
        state: ["", Validators.required],
        zipCode: [
          "",
          [Validators.required, Validators.pattern(this.numberonlyZipCode)]
        ],
        country: ["", Validators.required],
        termsAndCondition: ["", Validators.required],
        password: ["", [Validators.required, Validators.minLength(6)]],
        confirmPassword: ["", Validators.required]
      },
      {
        validator: MustMatch("password", "confirmPassword")
      }
    );
  }
  // convenience getter for easy access to form fields
  get f() {
    return this.registerForm.controls;
  }

  onSubmit() {
    this.submitted = true;
    var available = false;

    //stop here if form is invalid
    if (this.registerForm.invalid) {
      return;
    }

    var currUserName = this.registerForm.value.email;
    //Checking user availability
    /*
    if (this.userService.checkExist(currUserName)) {
      this.toastr.success("Please Login", "already have account");
      this.router.navigate(["/login"]); //redirect to login
    } else {
      this.userService.createUser(this.registerForm.value).subscribe(
        res => {
          let id = res["key"];
          console.log(id);
          this.toastr.success("Welcome", "You Have successfully Registered");
          this.router.navigate(["/home"]);
        },
        err => {
          console.log(err);
        }
      );
    }
    */

    var datas = localStorage["userDatas"];
    var currUserEmail: string;

    //check local storage is empty
    if (datas !== undefined) {
      datas = JSON.parse(datas);

      datas.forEach(function(element) {
        if (element.email == currUserName) {
          available = true; //if exists
          return false;
        }
      });
      //new user Registration
      if (!available) {
        datas.push(this.registerForm.value);
        localStorage["userDatas"] = JSON.stringify(datas);
        currUserEmail = this.registerForm.value.email;
        localStorage[currUserEmail] = JSON.stringify(datas);
        this.toastr.success("Welcome", "You Have successfully Registered");
        localStorage["logedUser"] = JSON.stringify(true);   
        localStorage["logedUserEmail"] = currUserEmail;
        this.router.navigate(["/"]);
        location.reload();
      } else {
        this.toastr.success("Please Login", "already have account");
        this.router.navigate(["/"]); //redirect to login
        location.reload();
      }
    } else {
      //when local storage empty create new user
      this.formdata.push(this.registerForm.value);
      localStorage["userDatas"] = JSON.stringify(this.formdata);
      currUserEmail = this.registerForm.value.email;
      localStorage[currUserEmail] = JSON.stringify(this.formdata);
      this.toastr.success("Welcome", "You Have successfully Registered");
      localStorage["logedUser"] = JSON.stringify(true);   
      localStorage["logedUserEmail"] = currUserEmail;
      this.router.navigate(["/"]);
      location.reload();
      this.router.routeReuseStrategy.shouldReuseRoute = function() {
        return true;
      };
      
    }
  }
}
