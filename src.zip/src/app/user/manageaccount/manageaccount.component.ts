import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manageaccount',
  templateUrl: './manageaccount.component.html',
  styleUrls: ['./manageaccount.component.css']
})
export class ManageaccountComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
