import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";

@Component({
  selector: 'app-accountinformation',
  templateUrl: './accountinformation.component.html',
  styleUrls: ['./accountinformation.component.css']
})
export class AccountinformationComponent implements OnInit {

  constructor(private router: Router) { }
  currentUserEmail: string;
  isLoggedIn: boolean;
  updatedCartall: any;
  updatedCartList: any;
  currentUser:any;

  ngOnInit() {
    if (!localStorage.getItem("logedUser")) {
      this.router.navigateByUrl("/");
    }
      this.currentUserEmail =localStorage.getItem("logedUserEmail");
      // console.log(this.currentUserEmail);
      

      this.currentUser= JSON.parse(localStorage.getItem(this.currentUserEmail))[0];
      console.log(this.currentUser);
      //console.log(localStorage.getItem("userDatas"));
      

     

  }
  
  
}

