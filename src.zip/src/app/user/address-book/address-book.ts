export interface IForm{
    email: string;
    firstName: string;
    lastName: string;
    number: number;
    StreetName: string;
    CityName: string;
    StateName: string;
    CountryName: string;
    Zip: string;
 }
 export class AddressBook implements IForm{
     constructor(public  email: string,
        public firstName: string,
        public lastName: string,
        public number: number,
        public StreetName: string,
        public CityName: string,
        public StateName: string,
        public CountryName: string,
        public Zip: string){

        }
    
            }