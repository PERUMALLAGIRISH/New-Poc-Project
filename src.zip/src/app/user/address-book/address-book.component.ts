import { Component, OnInit } from '@angular/core';
import { ToastrService } from "ngx-toastr";
import { FormGroup, Validators, FormBuilder } from '../../../../node_modules/@angular/forms';
import { Router } from '../../../../node_modules/@angular/router';

@Component({
  selector: 'app-address-book',
  templateUrl: './address-book.component.html',
  styleUrls: ['./address-book.component.css']
})
export class AddressBookComponent implements OnInit {
  editAddress: any;
  constructor(private formBuilder: FormBuilder,public toastr: ToastrService,private router: Router)  {}
  addressForm: FormGroup;
  addresses: any;
  addressEditForm: FormGroup;
  submitted = false;
  formdata = [];
  userName:string;
  alphaNumaric = "^[A-Za-z0-9_]{3,50}$";
  numberonlyPhone = "^[0-9]{10,10}$";
  numberonlyZipCode = "^[0-9]{6,6}$";
  userEmail = localStorage["logedUserEmail"];
  ngOnInit() {
    if (!localStorage.getItem("logedUser")) {
      this.router.navigate(['/']);
    }
    this.addressForm = this.formBuilder.group(
      {
        firstName: [
          "",
          [Validators.required, Validators.pattern(this.alphaNumaric)]
        ],
        lastName: [
          "",
          [Validators.required, Validators.pattern(this.alphaNumaric)]
        ],
        phoneNumber: [
          "",
          [Validators.required, Validators.pattern(this.numberonlyPhone)]
        ],
        cityName: [
          "",Validators.required
        ],
        stateName: [
          "",Validators.required
        ],
        streetName: [
          "",Validators.required
        ],
        countryName: [
          "",Validators.required
        ],
        zipCode: [
          "",
          [Validators.required, Validators.pattern(this.numberonlyZipCode)]
        ]
      }
    );
    this.addressEditForm = this.formBuilder.group(
      {
        firstName: [
          "",
          [Validators.required, Validators.pattern(this.alphaNumaric)]
        ],
        lastName: [
          "",
          [Validators.required, Validators.pattern(this.alphaNumaric)]
        ],
        phoneNumber: [
          "",
          [Validators.required, Validators.pattern(this.numberonlyPhone)]
        ],
        cityName: [
          "",Validators.required
        ],
        stateName: [
          "",Validators.required
        ],
        streetName: [
          "",Validators.required
        ],
        countryName: [
          "",Validators.required
        ],
        zipCode: [
          "",
          [Validators.required, Validators.pattern(this.numberonlyZipCode)]
        ]
      }
    );
    this.addresses = JSON.parse(localStorage[this.userEmail]);
    this.addresses = this.addresses.filter(function (el) {
      return el != null;
    });
   this.userName = this.addresses[0].firstName;
  }
  editaddress(value) {
    this.editAddress = this.addresses[value];   
    this.addressEditForm.setValue(this.editAddress);
  }

  deleteaddress(value) {
    var datas = localStorage[this.userEmail];
    datas = JSON.parse(datas);
    datas[value] = []; 
    datas.splice(value, 1);
    localStorage[this.userEmail] = JSON.stringify(datas);
    this.addresses = JSON.parse(localStorage[this.userEmail]);
  }
  // convenience getter for easy access to form fields
  get f() {
    return this.addressForm.controls;
  }
  onSubmit(){
    this.submitted = true;

    //stop here if form is invalid
    if (this.addressForm.invalid) {
      return;
    }

    var datas = localStorage[this.userEmail];
    //check local storage is empty
    if (datas !== undefined) {
      datas = JSON.parse(datas);
      datas.push(this.addressForm.value);
      localStorage[this.userEmail] = JSON.stringify(datas);
    } else {
      this.formdata.push(this.addressForm.value);
      localStorage[this.userEmail] = JSON.stringify(this.formdata);
    }
    var element = document.getElementById("closeAddress"); 
    element.click();
    this.addresses = JSON.parse(localStorage[this.userEmail]);
    this.toastr.success("You have successfully added new address.");
  }    
  onUpdate(value) {
    var datas = localStorage[this.userEmail];
    datas = JSON.parse(datas);
    datas[value] = this.addressEditForm.value;
    localStorage[this.userEmail] = JSON.stringify(datas);
    var element = document.getElementById("closeEditAddress-"+value); 
    element.click();
    this.addresses = JSON.parse(localStorage[this.userEmail]);
    this.toastr.success("You have successfully updated the address.");
  }
}