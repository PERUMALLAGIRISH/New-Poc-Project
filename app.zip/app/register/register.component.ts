import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";

@Component({
  selector: "app-register",
  templateUrl: "./register.component.html",
  styleUrls: ["./register.component.css"]
})
export class RegisterComponent implements OnInit {
  registerForm: FormGroup;
  submitted = false;
  alphaNumaric = "^[A-Za-z0-9_]{3,50}$";
  email = "^[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,4}$";
  numberonlyPhone = "^[0-9]{10,10}$";
  numberonlyZipCode = "^[0-9]{6,6}$";
  formdata = [];

  constructor(private formBuilder: FormBuilder, private router: Router) {}

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      firstName: [
        "",
        [Validators.required, Validators.pattern(this.alphaNumaric)]
      ],
      lastName: [
        "",
        [Validators.required, Validators.pattern(this.alphaNumaric)]
      ],
      email: ["", [Validators.required, Validators.pattern(this.email)]],
      PhoneNumber: [
        "",
        [Validators.required, Validators.pattern(this.numberonlyPhone)]
      ],
      streetName: ["", Validators.required],
      addressLineTwo: [""],
      cityName: ["", Validators.required],
      stateName: ["", Validators.required],
      zipCode: [
        "",
        [Validators.required, Validators.pattern(this.numberonlyZipCode)]
      ],
      countryName: ["", Validators.required],
      termsAndCondition: ["", Validators.required],
      password: ["", [Validators.required, Validators.minLength(6)]],
      confirmPassword: ["", Validators.required]
    });
  }

  //Geting form data for validacation
  get getFormValue() {
    return this.registerForm.controls;
  }

  //Submiting form
  registerUser() {}
}
